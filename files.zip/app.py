from flask import Flask, request, jsonify, send_from_directory
import pickle
import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import requests
import json
import os

app = Flask(__name__, static_folder='static')

# Add CORS headers manually
@app.after_request
def after_request(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type')
    response.headers.add('Access-Control-Allow-Methods', 'GET,POST,OPTIONS')
    return response

class AQIPredictor:
    """Real-time AQI prediction with API integration"""
    
    def __init__(self):
        self.load_models()
        self.iqair_api_key = None  # Users can set their own API key
        
    def load_models(self):
        """Load trained models"""
        try:
            with open('aqi_models.pkl', 'rb') as f:
                model_data = pickle.load(f)
                self.models = model_data['models']
                self.scalers = model_data['scalers']
                self.feature_names = model_data['feature_names']
                self.last_data = model_data['last_data']
                self.metrics = model_data['metrics']
            print("✓ Models loaded successfully")
        except Exception as e:
            print(f"Error loading models: {e}")
            raise
    
    def get_current_aqi_iqair(self, city):
        """Fetch current AQI from IQAir API"""
        # Free API endpoint (limited to major cities)
        # Users need to sign up at https://www.iqair.com/air-pollution-data-api
        
        city_mapping = {
            'Delhi': 'delhi',
            'Mumbai': 'mumbai',
            'Hyderabad': 'hyderabad',
            'Jaipur': 'jaipur',
            'Noida': 'noida'
        }
        
        if not self.iqair_api_key:
            # Return mock data if no API key
            return self.get_mock_current_aqi(city)
        
        try:
            url = f"http://api.airvisual.com/v2/city?city={city_mapping.get(city, city.lower())}&state=India&country=India&key={self.iqair_api_key}"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                aqi = data['data']['current']['pollution']['aqius']
                return {
                    'aqi': aqi,
                    'source': 'IQAir',
                    'timestamp': datetime.now().isoformat()
                }
        except Exception as e:
            print(f"IQAir API error: {e}")
        
        return self.get_mock_current_aqi(city)
    
    def get_current_aqi_openaq(self, city):
        """Fetch current AQI from OpenAQ API (free, no key required)"""
        try:
            # OpenAQ API v2
            url = f"https://api.openaq.org/v2/latest?city={city}&country=IN&limit=1"
            response = requests.get(url, timeout=5)
            
            if response.status_code == 200:
                data = response.json()
                if data.get('results'):
                    measurements = data['results'][0].get('measurements', [])
                    pm25_data = [m for m in measurements if m['parameter'] == 'pm25']
                    
                    if pm25_data:
                        pm25_value = pm25_data[0]['value']
                        aqi = self.pm25_to_aqi(pm25_value)
                        return {
                            'aqi': aqi,
                            'pm25': pm25_value,
                            'source': 'OpenAQ',
                            'timestamp': datetime.now().isoformat()
                        }
        except Exception as e:
            print(f"OpenAQ API error: {e}")
        
        return self.get_mock_current_aqi(city)
    
    def get_mock_current_aqi(self, city):
        """Get mock current AQI based on last known data"""
        if city in self.last_data:
            last_aqi = self.last_data[city]['AQI'].iloc[-1]
            # Add some realistic variation
            variation = np.random.normal(0, 10)
            current_aqi = max(0, last_aqi + variation)
            
            return {
                'aqi': int(current_aqi),
                'source': 'Historical (Demo)',
                'timestamp': datetime.now().isoformat()
            }
        
        return {'aqi': 100, 'source': 'Default', 'timestamp': datetime.now().isoformat()}
    
    def pm25_to_aqi(self, pm25):
        """Convert PM2.5 concentration to AQI"""
        if pm25 <= 12.0:
            return self._linear_scale(pm25, 0, 12.0, 0, 50)
        elif pm25 <= 35.4:
            return self._linear_scale(pm25, 12.1, 35.4, 51, 100)
        elif pm25 <= 55.4:
            return self._linear_scale(pm25, 35.5, 55.4, 101, 150)
        elif pm25 <= 150.4:
            return self._linear_scale(pm25, 55.5, 150.4, 151, 200)
        elif pm25 <= 250.4:
            return self._linear_scale(pm25, 150.5, 250.4, 201, 300)
        elif pm25 <= 350.4:
            return self._linear_scale(pm25, 250.5, 350.4, 301, 400)
        else:
            return self._linear_scale(pm25, 350.5, 500.4, 401, 500)
    
    def _linear_scale(self, value, c_low, c_high, i_low, i_high):
        """Linear interpolation for AQI calculation"""
        return int(((i_high - i_low) / (c_high - c_low)) * (value - c_low) + i_low)
    
    def create_features_for_prediction(self, city, current_aqi):
        """Create feature vector for prediction"""
        # Get historical data
        hist_data = self.last_data[city].copy()
        
        # Append current AQI
        new_row = pd.DataFrame({
            'Date': [datetime.now()],
            'AQI': [current_aqi],
            'City': [city]
        })
        
        df = pd.concat([hist_data, new_row], ignore_index=True)
        df = df.sort_values('Date').reset_index(drop=True)
        
        # Create features (same as training)
        df_features = self._create_features(df)
        
        # Get last row features
        feature_vector = df_features[self.feature_names].iloc[-1:].values
        
        return feature_vector
    
    def _create_features(self, df):
        """Create same features as training"""
        df = df.copy()
        
        # Lag features
        for lag in [1, 2, 3, 7, 14]:
            df[f'AQI_lag_{lag}'] = df['AQI'].shift(lag)
        
        # Rolling statistics
        for window in [3, 7, 14]:
            df[f'AQI_rolling_mean_{window}'] = df['AQI'].rolling(window=window, min_periods=1).mean()
            df[f'AQI_rolling_std_{window}'] = df['AQI'].rolling(window=window, min_periods=1).std()
            df[f'AQI_rolling_min_{window}'] = df['AQI'].rolling(window=window, min_periods=1).min()
            df[f'AQI_rolling_max_{window}'] = df['AQI'].rolling(window=window, min_periods=1).max()
        
        # Temporal features
        df['day_of_week'] = df['Date'].dt.dayofweek
        df['day_of_month'] = df['Date'].dt.day
        df['month'] = df['Date'].dt.month
        df['day_of_year'] = df['Date'].dt.dayofyear
        
        # Cyclical encoding
        df['day_of_week_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_of_week_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
        
        # Difference features
        df['AQI_diff_1'] = df['AQI'].diff(1)
        df['AQI_diff_7'] = df['AQI'].diff(7)
        
        # Exponential moving averages
        df['AQI_ema_3'] = df['AQI'].ewm(span=3, adjust=False).mean()
        df['AQI_ema_7'] = df['AQI'].ewm(span=7, adjust=False).mean()
        
        return df
    
    def predict_next_day(self, city, current_aqi=None):
        """Predict next day AQI"""
        if city not in self.models:
            return {'error': f'Model not available for {city}'}
        
        # Get current AQI
        if current_aqi is None:
            current_data = self.get_current_aqi_openaq(city)
            current_aqi = current_data['aqi']
        
        # Create feature vector
        try:
            features = self.create_features_for_prediction(city, current_aqi)
            
            # Scale features
            scaler = self.scalers[city]
            features_scaled = scaler.transform(features)
            
            # Predict
            model = self.models[city]
            predicted_aqi = model.predict(features_scaled)[0]
            
            # Get 7-day forecast
            forecast_7day = self.get_7day_forecast(city, current_aqi)
            
            return {
                'city': city,
                'current_aqi': int(current_aqi),
                'predicted_aqi_tomorrow': int(predicted_aqi),
                'current_status': self.get_aqi_status(current_aqi),
                'predicted_status': self.get_aqi_status(predicted_aqi),
                'forecast_7day': forecast_7day,
                'model_metrics': self.metrics[city],
                'timestamp': datetime.now().isoformat()
            }
        except Exception as e:
            return {'error': str(e)}
    
    def get_7day_forecast(self, city, current_aqi):
        """Generate 7-day forecast"""
        forecast = []
        last_aqi = current_aqi
        
        for day in range(1, 8):
            try:
                features = self.create_features_for_prediction(city, last_aqi)
                features_scaled = self.scalers[city].transform(features)
                predicted_aqi = self.models[city].predict(features_scaled)[0]
                
                forecast_date = (datetime.now() + timedelta(days=day)).strftime('%Y-%m-%d')
                forecast.append({
                    'date': forecast_date,
                    'aqi': int(predicted_aqi),
                    'status': self.get_aqi_status(predicted_aqi)['status']
                })
                
                last_aqi = predicted_aqi
            except:
                break
        
        return forecast
    
    def get_aqi_status(self, aqi):
        """Get AQI category and health implications"""
        if aqi <= 50:
            return {
                'status': 'Good',
                'color': '#00e400',
                'alert_level': 'none',
                'message': 'Air quality is satisfactory, and air pollution poses little or no risk.',
                'recommendations': ['Enjoy outdoor activities']
            }
        elif aqi <= 100:
            return {
                'status': 'Moderate',
                'color': '#ffff00',
                'alert_level': 'none',
                'message': 'Air quality is acceptable. However, there may be a risk for some people.',
                'recommendations': ['Unusually sensitive people should consider limiting prolonged outdoor exertion']
            }
        elif aqi <= 150:
            return {
                'status': 'Unhealthy for Sensitive Groups',
                'color': '#ff7e00',
                'alert_level': 'caution',
                'message': 'Members of sensitive groups may experience health effects.',
                'recommendations': [
                    'Children, elderly, and people with respiratory issues should limit outdoor exertion',
                    'Consider wearing a mask outdoors',
                    'Use air purifiers indoors'
                ]
            }
        elif aqi <= 200:
            return {
                'status': 'Unhealthy',
                'color': '#ff0000',
                'alert_level': 'alert',
                'message': 'Everyone may begin to experience health effects.',
                'recommendations': [
                    'Everyone should limit prolonged outdoor exertion',
                    'Wear N95 mask outdoors',
                    'Keep windows closed',
                    'Use air purifiers',
                    'Sensitive groups should avoid outdoor activities'
                ]
            }
        elif aqi <= 300:
            return {
                'status': 'Very Unhealthy',
                'color': '#8f3f97',
                'alert_level': 'major_alert',
                'message': 'Health alert: everyone may experience more serious health effects.',
                'recommendations': [
                    'Everyone should avoid outdoor activities',
                    'Wear N95/N99 mask if going outside',
                    'Keep all windows and doors closed',
                    'Use air purifiers on high',
                    'Monitor health symptoms closely'
                ]
            }
        else:
            return {
                'status': 'Hazardous',
                'color': '#7e0023',
                'alert_level': 'emergency',
                'message': 'Health warning of emergency conditions. Everyone is likely to be affected.',
                'recommendations': [
                    'Stay indoors at all times',
                    'Seal windows and doors',
                    'Use air purifiers continuously',
                    'Avoid all physical exertion',
                    'Seek medical attention if experiencing symptoms',
                    'Consider relocating temporarily if possible'
                ]
            }

# Initialize predictor
predictor = AQIPredictor()

# API Routes
@app.route('/')
def index():
    """Serve main HTML page"""
    return send_from_directory('static', 'index.html')

@app.route('/api/cities', methods=['GET'])
def get_cities():
    """Get list of available cities"""
    cities = list(predictor.models.keys())
    return jsonify({'cities': cities})

@app.route('/api/predict', methods=['POST'])
def predict():
    """Get AQI prediction for a city"""
    data = request.json
    city = data.get('city', 'Delhi')
    current_aqi = data.get('current_aqi')
    
    result = predictor.predict_next_day(city, current_aqi)
    return jsonify(result)

@app.route('/api/current/<city>', methods=['GET'])
def get_current(city):
    """Get current AQI for a city"""
    current_data = predictor.get_current_aqi_openaq(city)
    return jsonify(current_data)

@app.route('/api/metrics', methods=['GET'])
def get_metrics():
    """Get model performance metrics"""
    return jsonify(predictor.metrics)

@app.route('/api/health-recommendations/<int:aqi>', methods=['GET'])
def get_health_recommendations(aqi):
    """Get health recommendations based on AQI"""
    status = predictor.get_aqi_status(aqi)
    return jsonify(status)

@app.route('/static/<path:path>')
def send_static(path):
    """Serve static files"""
    return send_from_directory('static', path)

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🚀 AQI PREDICTION API SERVER")
    print("="*60)
    print("Server running at: http://localhost:5000")
    print("API endpoints available:")
    print("  - GET  /api/cities")
    print("  - POST /api/predict")
    print("  - GET  /api/current/<city>")
    print("  - GET  /api/metrics")
    print("  - GET  /api/health-recommendations/<aqi>")
    print("="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
