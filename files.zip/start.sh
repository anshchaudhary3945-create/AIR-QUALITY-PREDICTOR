#!/bin/bash

echo "=================================="
echo "AQI Prediction System - Launcher"
echo "=================================="
echo ""

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✓ Python 3 found"

# Check if requirements are installed
echo "Checking dependencies..."
python3 -c "import flask, pandas, numpy, sklearn, openpyxl, requests" 2>/dev/null

if [ $? -ne 0 ]; then
    echo "⚠️  Some dependencies are missing. Installing..."
    pip install -r requirements.txt --break-system-packages
else
    echo "✓ All dependencies installed"
fi

# Check if models exist
if [ ! -f "aqi_models.pkl" ]; then
    echo ""
    echo "⚠️  Models not found. Training models..."
    python3 train_model.py
    echo ""
fi

echo ""
echo "🚀 Starting AQI Prediction Server..."
echo "   Open your browser to: http://localhost:5000"
echo ""
echo "   Press Ctrl+C to stop the server"
echo ""
python3 app.py
