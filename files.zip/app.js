// API Configuration
const API_BASE_URL = window.location.origin;

// Global state
let currentCity = 'Delhi';
let currentData = null;

// Initialize app on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
});

function initializeApp() {
    console.log('Initializing AQI Prediction App...');
    loadCityData(currentCity);
}

function setupEventListeners() {
    // City selector
    document.getElementById('citySelector').addEventListener('change', function(e) {
        currentCity = e.target.value;
        loadCityData(currentCity);
    });
    
    // Check AQI button
    document.getElementById('checkAQIBtn').addEventListener('click', function() {
        loadCityData(currentCity);
    });
    
    // How it works modal
    document.getElementById('howItWorksBtn').addEventListener('click', openModal);
    document.querySelector('.modal-close').addEventListener('click', closeModal);
    
    // Enable alerts button
    document.getElementById('enableAlertsBtn').addEventListener('click', enableAlerts);
    
    // Close modal on outside click
    window.addEventListener('click', function(e) {
        const modal = document.getElementById('howItWorksModal');
        if (e.target === modal) {
            closeModal();
        }
    });
}

async function loadCityData(city) {
    showLoading(true);
    
    try {
        // Fetch prediction data
        const response = await fetch(`${API_BASE_URL}/api/predict`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ city: city })
        });
        
        if (!response.ok) {
            throw new Error('Failed to fetch data');
        }
        
        const data = await response.json();
        
        if (data.error) {
            throw new Error(data.error);
        }
        
        currentData = data;
        updateUI(data);
        
    } catch (error) {
        console.error('Error loading city data:', error);
        showError('Failed to load air quality data. Please try again.');
    } finally {
        showLoading(false);
    }
}

function updateUI(data) {
    // Update today's AQI
    updateTodayAQI(data.current_aqi, data.current_status);
    
    // Update tomorrow's prediction
    updateTomorrowPrediction(data.predicted_aqi_tomorrow, data.predicted_status, data.current_aqi);
    
    // Update 7-day forecast
    update7DayForecast(data.forecast_7day);
    
    // Update health recommendations
    updateHealthRecommendations(data.predicted_status);
    
    // Update alert box
    updateAlertBox(data.predicted_status);
    
    // Update model metrics
    updateModelMetrics(data.model_metrics);
}

function updateTodayAQI(aqi, status) {
    const aqiNumber = document.getElementById('todayAQI');
    const aqiLabel = document.getElementById('todayLabel');
    const aqiIcon = document.getElementById('todayIcon');
    
    aqiNumber.textContent = aqi;
    aqiLabel.textContent = status.status;
    
    // Update color based on AQI
    const color = status.color;
    aqiNumber.style.color = color;
    
    // Update icon color
    const circles = aqiIcon.querySelectorAll('circle');
    circles[0].setAttribute('fill', color);
    circles[0].setAttribute('opacity', '0.3');
    circles[1].setAttribute('fill', color);
}

function updateTomorrowPrediction(predictedAQI, status, currentAQI) {
    const trendText = document.getElementById('trendText');
    const canvas = document.getElementById('trendChart');
    const ctx = canvas.getContext('2d');
    
    // Determine trend
    const diff = predictedAQI - currentAQI;
    let trendMessage = '';
    
    if (diff > 10) {
        trendMessage = 'Expected Decline in Air Quality';
    } else if (diff < -10) {
        trendMessage = 'Expected Improvement';
    } else {
        trendMessage = 'Expected to Remain Similar';
    }
    
    trendText.textContent = trendMessage;
    trendText.style.color = diff < -10 ? '#00e400' : diff > 10 ? '#dc2626' : '#0ea5e9';
    
    // Draw trend chart
    drawTrendChart(ctx, canvas, currentAQI, predictedAQI);
}

function drawTrendChart(ctx, canvas, current, predicted) {
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const width = canvas.width;
    const height = canvas.height;
    const padding = 20;
    
    // Calculate points
    const maxAQI = Math.max(current, predicted, 200);
    const x1 = padding;
    const y1 = height - padding - ((current / maxAQI) * (height - 2 * padding));
    const x2 = width - padding;
    const y2 = height - padding - ((predicted / maxAQI) * (height - 2 * padding));
    
    // Draw line
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    
    // Smooth curve
    const cpx = (x1 + x2) / 2;
    const cpy = (y1 + y2) / 2;
    ctx.quadraticCurveTo(cpx, cpy, x2, y2);
    
    ctx.strokeStyle = '#0ea5e9';
    ctx.lineWidth = 3;
    ctx.stroke();
    
    // Draw arrow
    const angle = Math.atan2(y2 - y1, x2 - x1);
    const arrowSize = 10;
    
    ctx.beginPath();
    ctx.moveTo(x2, y2);
    ctx.lineTo(
        x2 - arrowSize * Math.cos(angle - Math.PI / 6),
        y2 - arrowSize * Math.sin(angle - Math.PI / 6)
    );
    ctx.moveTo(x2, y2);
    ctx.lineTo(
        x2 - arrowSize * Math.cos(angle + Math.PI / 6),
        y2 - arrowSize * Math.sin(angle + Math.PI / 6)
    );
    ctx.stroke();
    
    // Draw points
    ctx.beginPath();
    ctx.arc(x1, y1, 5, 0, 2 * Math.PI);
    ctx.fillStyle = '#0ea5e9';
    ctx.fill();
    
    ctx.beginPath();
    ctx.arc(x2, y2, 5, 0, 2 * Math.PI);
    ctx.fillStyle = '#0ea5e9';
    ctx.fill();
}

function update7DayForecast(forecast) {
    const canvas = document.getElementById('weekChart');
    const ctx = canvas.getContext('2d');
    
    if (!forecast || forecast.length === 0) {
        return;
    }
    
    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    
    const width = canvas.width;
    const height = canvas.height;
    const padding = 20;
    const plotWidth = width - 2 * padding;
    const plotHeight = height - 2 * padding;
    
    // Get AQI values
    const aqiValues = forecast.map(f => f.aqi);
    const maxAQI = Math.max(...aqiValues, 200);
    const minAQI = Math.min(...aqiValues, 0);
    
    // Draw line chart
    ctx.beginPath();
    ctx.strokeStyle = '#0ea5e9';
    ctx.lineWidth = 2;
    
    forecast.forEach((point, index) => {
        const x = padding + (index / (forecast.length - 1)) * plotWidth;
        const y = height - padding - ((point.aqi - minAQI) / (maxAQI - minAQI)) * plotHeight;
        
        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
        
        // Draw point
        ctx.fillStyle = getAQIColor(point.aqi);
        ctx.beginPath();
        ctx.arc(x, y, 4, 0, 2 * Math.PI);
        ctx.fill();
    });
    
    ctx.stroke();
}

function updateHealthRecommendations(status) {
    const grid = document.getElementById('recommendationsGrid');
    const recommendations = status.recommendations || [];
    
    if (recommendations.length === 0) {
        return;
    }
    
    // Create recommendation cards
    let html = '';
    
    // Icon mapping based on common recommendations
    const iconMap = {
        'mask': '😷',
        'outdoor': '🏃‍♂️',
        'purifier': '💨',
        'window': '🪟',
        'sensitive': '👥',
        'avoid': '⛔',
        'indoor': '🏠',
        'monitor': '📊'
    };
    
    recommendations.forEach(rec => {
        let icon = '💡'; // Default icon
        
        // Find matching icon
        for (const [key, emoji] of Object.entries(iconMap)) {
            if (rec.toLowerCase().includes(key)) {
                icon = emoji;
                break;
            }
        }
        
        html += `
            <div class="recommendation-card">
                <div class="rec-icon">${icon}</div>
                <p>${rec}</p>
            </div>
        `;
    });
    
    grid.innerHTML = html;
}

function updateAlertBox(status) {
    const alertBox = document.getElementById('alertBox');
    const alertMessage = document.getElementById('alertMessage');
    
    // Show alert for unhealthy conditions
    if (status.alert_level !== 'none') {
        alertBox.style.display = 'flex';
        alertMessage.textContent = status.message;
        
        // Update color based on severity
        if (status.alert_level === 'emergency' || status.alert_level === 'major_alert') {
            alertBox.style.backgroundColor = '#dc2626';
            alertBox.style.color = 'white';
        } else if (status.alert_level === 'alert') {
            alertBox.style.backgroundColor = '#ff7e00';
            alertBox.style.color = 'white';
        } else {
            alertBox.style.backgroundColor = '#ffc107';
            alertBox.style.color = '#1f2937';
        }
    } else {
        alertBox.style.display = 'none';
    }
}

function updateModelMetrics(metrics) {
    if (!metrics) return;
    
    document.getElementById('r2Score').textContent = metrics.r2.toFixed(4);
    document.getElementById('maeScore').textContent = metrics.mae.toFixed(2) + ' AQI';
    
    const lastUpdated = new Date().toLocaleDateString();
    document.getElementById('lastUpdated').textContent = lastUpdated;
}

function getAQIColor(aqi) {
    if (aqi <= 50) return '#00e400';
    if (aqi <= 100) return '#ffff00';
    if (aqi <= 150) return '#ff7e00';
    if (aqi <= 200) return '#ff0000';
    if (aqi <= 300) return '#8f3f97';
    return '#7e0023';
}

function openModal() {
    document.getElementById('howItWorksModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('howItWorksModal').style.display = 'none';
}

function enableAlerts() {
    const contact = document.getElementById('contactInput').value;
    const dailyAlerts = document.getElementById('dailyAlerts').checked;
    const emergencyAlerts = document.getElementById('emergencyAlerts').checked;
    
    if (!contact) {
        alert('Please enter your mobile number or email address.');
        return;
    }
    
    // Validate email or phone
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const phoneRegex = /^\d{10}$/;
    
    if (!emailRegex.test(contact) && !phoneRegex.test(contact)) {
        alert('Please enter a valid email address or 10-digit phone number.');
        return;
    }
    
    // In production, this would send to backend
    alert(`✅ Alerts enabled successfully!\n\nYou'll receive notifications at: ${contact}\n\nDaily AQI: ${dailyAlerts ? 'ON' : 'OFF'}\nEmergency Alerts: ${emergencyAlerts ? 'ON' : 'OFF'}`);
    
    // Clear input
    document.getElementById('contactInput').value = '';
}

function showLoading(show) {
    const overlay = document.getElementById('loadingOverlay');
    overlay.style.display = show ? 'flex' : 'none';
}

function showError(message) {
    alert('Error: ' + message);
}

// Auto-refresh every 15 minutes
setInterval(() => {
    loadCityData(currentCity);
}, 15 * 60 * 1000);
