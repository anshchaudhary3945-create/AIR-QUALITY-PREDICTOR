import pandas as pd
import numpy as np
import pickle
import json
from datetime import datetime, timedelta
from sklearn.ensemble import GradientBoostingRegressor, RandomForestRegressor
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import warnings
warnings.filterwarnings('ignore')

class AQIModelTrainer:
    """
    Advanced AQI prediction model with improved feature engineering
    and validation strategies
    """
    
    def __init__(self):
        self.models = {}
        self.scalers = {}
        self.feature_names = None
        self.cities = ['Delhi', 'Mumbai', 'Hyderabad', 'Jaipur', 'Noida']
        
    def load_and_transform_data(self, filepath, city_name):
        """Transform monthly format data into time-series format"""
        df = pd.read_excel(filepath)
        
        # Remove the last row if it's a summary row
        df = df[df['Day'].notna()]
        
        # Convert to time-series format
        records = []
        for month_col in df.columns[1:]:  # Skip 'Day' column
            if df[month_col].notna().sum() > 0:  # Only process months with data
                for idx, row in df.iterrows():
                    day = row['Day']
                    aqi_value = row[month_col]
                    
                    if pd.notna(day) and pd.notna(aqi_value):
                        try:
                            # Parse day (handle formats like "1", "2", etc.)
                            day_num = int(str(day).strip())
                            
                            # Create date (assuming 2025 data)
                            month_num = datetime.strptime(month_col, '%B').month
                            date = datetime(2025, month_num, day_num)
                            
                            records.append({
                                'Date': date,
                                'AQI': float(aqi_value),
                                'City': city_name
                            })
                        except:
                            continue
        
        df_timeseries = pd.DataFrame(records)
        df_timeseries = df_timeseries.sort_values('Date').reset_index(drop=True)
        
        return df_timeseries
    
    def create_advanced_features(self, df):
        """Create comprehensive feature set for improved predictions"""
        df = df.copy()
        df = df.sort_values('Date').reset_index(drop=True)
        
        # 1. Lag features (past values)
        for lag in [1, 2, 3, 7, 14]:
            df[f'AQI_lag_{lag}'] = df['AQI'].shift(lag)
        
        # 2. Rolling statistics (trends)
        for window in [3, 7, 14]:
            df[f'AQI_rolling_mean_{window}'] = df['AQI'].rolling(window=window, min_periods=1).mean()
            df[f'AQI_rolling_std_{window}'] = df['AQI'].rolling(window=window, min_periods=1).std()
            df[f'AQI_rolling_min_{window}'] = df['AQI'].rolling(window=window, min_periods=1).min()
            df[f'AQI_rolling_max_{window}'] = df['AQI'].rolling(window=window, min_periods=1).max()
        
        # 3. Temporal features
        df['day_of_week'] = df['Date'].dt.dayofweek
        df['day_of_month'] = df['Date'].dt.day
        df['month'] = df['Date'].dt.month
        df['day_of_year'] = df['Date'].dt.dayofyear
        
        # 4. Cyclical encoding for temporal features
        df['day_of_week_sin'] = np.sin(2 * np.pi * df['day_of_week'] / 7)
        df['day_of_week_cos'] = np.cos(2 * np.pi * df['day_of_week'] / 7)
        df['month_sin'] = np.sin(2 * np.pi * df['month'] / 12)
        df['month_cos'] = np.cos(2 * np.pi * df['month'] / 12)
        
        # 5. Difference features (rate of change)
        df['AQI_diff_1'] = df['AQI'].diff(1)
        df['AQI_diff_7'] = df['AQI'].diff(7)
        
        # 6. Exponential moving averages
        df['AQI_ema_3'] = df['AQI'].ewm(span=3, adjust=False).mean()
        df['AQI_ema_7'] = df['AQI'].ewm(span=7, adjust=False).mean()
        
        return df
    
    def prepare_training_data(self, df, lookback=14):
        """Prepare features and target, removing NaN values"""
        df_features = self.create_advanced_features(df)
        
        # Drop rows with NaN (from lag features)
        df_features = df_features.dropna()
        
        if len(df_features) < 30:
            raise ValueError(f"Insufficient data after feature engineering. Need at least 30 samples, got {len(df_features)}")
        
        # Define feature columns (exclude Date, AQI, City)
        feature_cols = [col for col in df_features.columns 
                       if col not in ['Date', 'AQI', 'City']]
        
        X = df_features[feature_cols]
        y = df_features['AQI']
        dates = df_features['Date']
        
        return X, y, dates, feature_cols
    
    def train_city_model(self, city_name, filepath):
        """Train model for a specific city with proper validation"""
        print(f"\n{'='*60}")
        print(f"Training model for {city_name}")
        print(f"{'='*60}")
        
        # Load and transform data
        df = self.load_and_transform_data(filepath, city_name)
        print(f"Loaded {len(df)} data points from {df['Date'].min().date()} to {df['Date'].max().date()}")
        
        # Prepare training data
        X, y, dates, feature_cols = self.prepare_training_data(df)
        self.feature_names = feature_cols
        
        print(f"Feature matrix shape: {X.shape}")
        print(f"Number of features: {len(feature_cols)}")
        
        # Use time series split for validation
        tscv = TimeSeriesSplit(n_splits=3)
        
        # Scale features
        scaler = StandardScaler()
        X_scaled = scaler.fit_transform(X)
        
        # Train Gradient Boosting model (generally better for time series)
        model = GradientBoostingRegressor(
            n_estimators=200,
            learning_rate=0.05,
            max_depth=5,
            min_samples_split=10,
            min_samples_leaf=4,
            subsample=0.8,
            random_state=42,
            verbose=0
        )
        
        # Cross-validation
        cv_scores = []
        for fold, (train_idx, val_idx) in enumerate(tscv.split(X_scaled)):
            X_train, X_val = X_scaled[train_idx], X_scaled[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
            
            model.fit(X_train, y_train)
            y_pred = model.predict(X_val)
            
            mae = mean_absolute_error(y_val, y_pred)
            rmse = np.sqrt(mean_squared_error(y_val, y_pred))
            r2 = r2_score(y_val, y_pred)
            
            cv_scores.append({'mae': mae, 'rmse': rmse, 'r2': r2})
            print(f"  Fold {fold+1}: MAE={mae:.2f}, RMSE={rmse:.2f}, R²={r2:.4f}")
        
        # Train final model on all data
        model.fit(X_scaled, y)
        
        # Final evaluation on last 20% of data
        split_idx = int(len(X_scaled) * 0.8)
        X_train_final = X_scaled[:split_idx]
        X_test_final = X_scaled[split_idx:]
        y_train_final = y.iloc[:split_idx]
        y_test_final = y.iloc[split_idx:]
        
        y_pred_final = model.predict(X_test_final)
        
        mae_final = mean_absolute_error(y_test_final, y_pred_final)
        rmse_final = np.sqrt(mean_squared_error(y_test_final, y_pred_final))
        r2_final = r2_score(y_test_final, y_pred_final)
        
        print(f"\n{'='*60}")
        print(f"FINAL MODEL PERFORMANCE FOR {city_name.upper()}")
        print(f"{'='*60}")
        print(f"Mean Absolute Error (MAE): {mae_final:.2f} AQI points")
        print(f"Root Mean Square Error (RMSE): {rmse_final:.2f} AQI points")
        print(f"R² Score: {r2_final:.4f}")
        print(f"Average CV MAE: {np.mean([s['mae'] for s in cv_scores]):.2f}")
        print(f"Average CV RMSE: {np.mean([s['rmse'] for s in cv_scores]):.2f}")
        print(f"Average CV R²: {np.mean([s['r2'] for s in cv_scores]):.4f}")
        
        # Store model and scaler
        self.models[city_name] = model
        self.scalers[city_name] = scaler
        
        # Store last known data for prediction
        last_data = df.tail(14).copy()  # Keep last 14 days for feature creation
        
        metrics = {
            'mae': mae_final,
            'rmse': rmse_final,
            'r2': r2_final,
            'cv_mae': np.mean([s['mae'] for s in cv_scores]),
            'cv_rmse': np.mean([s['rmse'] for s in cv_scores]),
            'cv_r2': np.mean([s['r2'] for s in cv_scores]),
            'training_samples': len(X),
            'last_date': dates.iloc[-1].strftime('%Y-%m-%d')
        }
        
        return metrics, last_data
    
    def train_all_models(self):
        """Train models for all cities"""
        city_files = {
            'Delhi': '/mnt/user-data/uploads/AQI_daily_city_level_delhi_2025_delhi_2025.xlsx',
            'Mumbai': '/mnt/user-data/uploads/AQI_daily_city_level_mumbai_2025_mumbai_2025.xlsx',
            'Hyderabad': '/mnt/user-data/uploads/AQI_daily_city_level_hyderabad_2025_hyderabad_2025.xlsx',
            'Jaipur': '/mnt/user-data/uploads/AQI_daily_city_level_jaipur_2025_jaipur_2025.xlsx',
            'Noida': '/mnt/user-data/uploads/AQI_daily_city_level_noida_2025_noida_2025.xlsx'
        }
        
        all_metrics = {}
        last_data_dict = {}
        
        for city, filepath in city_files.items():
            try:
                metrics, last_data = self.train_city_model(city, filepath)
                all_metrics[city] = metrics
                last_data_dict[city] = last_data
            except Exception as e:
                print(f"Error training model for {city}: {e}")
                continue
        
        # Save models and metadata
        self.save_models(all_metrics, last_data_dict)
        
        return all_metrics
    
    def save_models(self, metrics, last_data_dict):
        """Save all models, scalers, and metadata"""
        model_data = {
            'models': self.models,
            'scalers': self.scalers,
            'feature_names': self.feature_names,
            'metrics': metrics,
            'last_data': last_data_dict,
            'trained_date': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        with open('/home/claude/aqi_models.pkl', 'wb') as f:
            pickle.dump(model_data, f)
        
        # Save metrics as JSON for easy access
        with open('/home/claude/model_metrics.json', 'w') as f:
            json.dump(metrics, f, indent=2)
        
        print(f"\n{'='*60}")
        print("Models saved successfully!")
        print(f"{'='*60}")
        print(f"Model file: aqi_models.pkl")
        print(f"Metrics file: model_metrics.json")
        print(f"\nSummary of all models:")
        print(f"{'City':<15} {'MAE':<10} {'RMSE':<10} {'R²':<10}")
        print(f"{'-'*45}")
        for city, metric in metrics.items():
            print(f"{city:<15} {metric['mae']:<10.2f} {metric['rmse']:<10.2f} {metric['r2']:<10.4f}")

if __name__ == '__main__':
    print("="*60)
    print("AQI PREDICTION MODEL TRAINER")
    print("="*60)
    
    trainer = AQIModelTrainer()
    metrics = trainer.train_all_models()
    
    print("\n" + "="*60)
    print("TRAINING COMPLETED SUCCESSFULLY!")
    print("="*60)
