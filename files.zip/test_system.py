#!/usr/bin/env python3
"""
Test script to verify the AQI prediction system
"""

import sys
import os

def test_model_loading():
    """Test if models can be loaded"""
    print("🧪 Testing model loading...")
    try:
        import pickle
        with open('aqi_models.pkl', 'rb') as f:
            model_data = pickle.load(f)
        
        cities = list(model_data['models'].keys())
        print(f"✅ Models loaded successfully for cities: {', '.join(cities)}")
        return True
    except Exception as e:
        print(f"❌ Model loading failed: {e}")
        return False

def test_prediction():
    """Test prediction functionality"""
    print("\n🧪 Testing prediction...")
    try:
        from app import AQIPredictor
        
        predictor = AQIPredictor()
        result = predictor.predict_next_day('Delhi', current_aqi=150)
        
        if 'error' in result:
            print(f"❌ Prediction failed: {result['error']}")
            return False
        
        print(f"✅ Prediction successful!")
        print(f"   Current AQI: {result['current_aqi']}")
        print(f"   Predicted AQI: {result['predicted_aqi_tomorrow']}")
        print(f"   Current Status: {result['current_status']['status']}")
        print(f"   Predicted Status: {result['predicted_status']['status']}")
        return True
    except Exception as e:
        print(f"❌ Prediction test failed: {e}")
        return False

def test_dependencies():
    """Test if all dependencies are installed"""
    print("\n🧪 Testing dependencies...")
    required_packages = [
        'flask',
        'pandas',
        'numpy',
        'sklearn',
        'openpyxl',
        'requests'
    ]
    
    missing = []
    for package in required_packages:
        try:
            __import__(package)
        except ImportError:
            missing.append(package)
    
    if missing:
        print(f"❌ Missing packages: {', '.join(missing)}")
        print(f"   Install with: pip install {' '.join(missing)}")
        return False
    else:
        print("✅ All dependencies installed")
        return True

def test_static_files():
    """Test if static files exist"""
    print("\n🧪 Testing static files...")
    required_files = [
        'static/index.html',
        'static/style.css',
        'static/app.js'
    ]
    
    missing = []
    for file in required_files:
        if not os.path.exists(file):
            missing.append(file)
    
    if missing:
        print(f"❌ Missing files: {', '.join(missing)}")
        return False
    else:
        print("✅ All static files present")
        return True

def main():
    print("="*60)
    print("AQI PREDICTION SYSTEM - TEST SUITE")
    print("="*60)
    
    tests = [
        ("Dependencies", test_dependencies),
        ("Model Loading", test_model_loading),
        ("Static Files", test_static_files),
        ("Prediction", test_prediction)
    ]
    
    results = []
    for test_name, test_func in tests:
        try:
            result = test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ {test_name} test crashed: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASS" if result else "❌ FAIL"
        print(f"{test_name:<20} {status}")
    
    print(f"\n{passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Your system is ready to use.")
        print("\nTo start the server, run:")
        print("  python app.py")
        print("\nThen open your browser to:")
        print("  http://localhost:5000")
    else:
        print("\n⚠️ Some tests failed. Please fix the issues above.")
        sys.exit(1)

if __name__ == '__main__':
    main()
